COGNITO_DOMAIN = "my-aws-cognito-domain.com"
CLIENT_ID = "my-aws-cognito-user-pool-app-client-id"
CLIENT_SECRET = "my-aws-cognito-user-pool-app-client-secret"
COGNITO_REGION = "my-aws-cognito-user-pool-region"
COGNITO_POOL_ID = "my-aws-cognito-user-pool-id"
WHITELIST_DOMAIN = []