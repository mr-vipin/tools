#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""Default configuration for the Airflow webserver"""
import os
import json
import sys
from flask import request
from jose import jwt
import requests
from requests.auth import HTTPBasicAuth
from flask_appbuilder.security.manager import AUTH_OAUTH
from airflow.www.security import AirflowSecurityManager

basedir = os.path.abspath(os.path.dirname(__file__))

if basedir not in sys.path:
    sys.path.append(basedir)

if True:
    import oauth2_config

# Flask-WTF flag for CSRF
WTF_CSRF_ENABLED = True
AUTH_TYPE = AUTH_OAUTH

# Will allow user self registration
AUTH_USER_REGISTRATION = True

# The default user self registration role
AUTH_USER_REGISTRATION_ROLE = "Viewer"
#AUTH_USER_REGISTRATION_ROLE = "Admin"


def verify(token: str, access_token: str = None):
    """
    Verifies a JWT string's signature and validates reserved claims.
    Get the key id from the header, locate it in the cognito keys and verify
    the key
    :param token (str):         A signed JWS to be verified.
    :param access_token (str):  An access token string. If the "at_hash" claim
                                is included in the
    :return id_token (dict):    The dict representation of the claims set,
                                assuming the signature is valid and all
                                requested data validation passes.
    """
    jwt_key = requests.get(jwt_cognito_public_key_uri).json()["keys"]
    header = jwt.get_unverified_header(token)

    key = [k for k in jwt_key if k["kid"] == header['kid']][0]
    id_token = jwt.decode(token,
                          key,
                          audience=oauth2_config.CLIENT_ID,
                          access_token=access_token)
    return id_token


class CognitoSecurity(AirflowSecurityManager):
    def oauth_user_info(self, provider, response=None):
        if provider == "aws_cognito":
            resp = str(response)
            resp = eval(resp)
            data = {}

            try:
                verify(resp["access_token"])
                id_token = verify(
                    resp["id_token"], resp["access_token"])

                username = None
                email = None
                if "identities" in id_token:
                    for identity in id_token['identities']:
                        if 'primary' in identity and identity['primary']:
                            if 'userId' in identity:
                                email = username = identity['userId']

                    if not username:
                        if len(id_token['identities']):
                            identity = id_token['identities'][0]
                            if 'userId' in identity:
                                email = username = identity['userId']

                if not username and "email" in id_token:
                    email = username = id_token["email"]
                elif not username:
                    email = username = id_token["cognito:username"]

                data = {"username": username,
                        "email": email}
                print(f"User info from aws_cognito: {data}")
                return {"username": data.get("username"), "email": data.get("email")}
            except Exception as e:
                print(e)
                return data
        else:
            return {}


domain = oauth2_config.COGNITO_DOMAIN
if not domain.startswith("https://"):
    domain = f"https://{domain}"

callback_uri = os.path.join(domain, 'oauth2/idpresponse')
login_uri = os.path.join(domain, 'oauth2/authorize')
jwt_access_token_uri = os.path.join(domain, 'oauth2/token')
jwt_cognito_public_key_uri = f"https://cognito-idp.{oauth2_config.COGNITO_REGION}.amazonaws.com/{oauth2_config.COGNITO_POOL_ID}/.well-known/jwks.json"

OAUTH_PROVIDERS = [{
    'name': 'aws_cognito',
    'whitelist': oauth2_config.WHITELIST_DOMAIN,
    'token_key': 'access_token',
    'url': domain,
    'icon': 'fa-amazon',
    'remote_app': {
        'base_url': callback_uri,
        'request_token_params': {
            'scope': 'email profile openid'
        },
        'access_token_url': jwt_access_token_uri,
        'authorize_url': login_uri,
        'request_token_url': None,
        'client_id': oauth2_config.CLIENT_ID,
        'client_secret': oauth2_config.CLIENT_SECRET,
    }
}]

if not OAUTH_PROVIDERS[0]["whitelist"]:
    OAUTH_PROVIDERS[0].pop("whitelist")


SECURITY_MANAGER_CLASS = CognitoSecurity